from flask import Flask, render_template, request, redirect, url_for
import sqlite3
app = Flask(__name__)

def create_connection():
    connection = sqlite3.connect('employees.db')
    return connection

def create_table():
    connection = create_connection()
    with connection:
        connection.execute("""
        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            age INTEGER,
            department TEXT,
            salary REAL
        );
        """)
    connection.close()

@app.route('/')
def index():
    connection = create_connection()
    employees = connection.execute("SELECT * FROM employees").fetchall()
    connection.close()
    return render_template('index.html', employees=employees)

@app.route('/add', methods=['GET', 'POST'])
def add_employee():
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        department = request.form['department']
        salary = request.form['salary']

        connection = create_connection()
        connection.execute("INSERT INTO employees (name, age, department, salary) VALUES (?, ?, ?, ?)", (name, age, department, salary))
        connection.commit()
        connection.close()

        return redirect(url_for('index'))
    return render_template('add_employee.html')

@app.route('/update/<int:id>', methods=['GET', 'POST'])
def update_employee(id):
    connection = create_connection()
    if request.method == 'POST':
        name = request.form['name']
        age = request.form['age']
        department = request.form['department']
        salary = request.form['salary']

        connection.execute("UPDATE employees SET name = ?, age = ?, department = ?, salary = ? WHERE id = ?", (name, age, department, salary, id))
        connection.commit()
        connection.close()

        return redirect(url_for('index'))
    employee = connection.execute("SELECT * FROM employees WHERE id = ?", (id,)).fetchone()
    connection.close()
    return render_template('update_employee.html', employee=employee)

@app.route('/delete/<int:id>', methods=['POST'])
def delete_employee(id):
    connection = create_connection()
    connection.execute("DELETE FROM employees WHERE id = ?", (id,))
    connection.commit()
    connection.close()
    return redirect(url_for('index'))

if __name__ == "__main__":
    create_table()
    app.run(debug=True)